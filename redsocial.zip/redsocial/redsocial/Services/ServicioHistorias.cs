﻿using System;
using System.Collections.Generic;
using System.Linq;
using RedSocial.Models;

namespace RedSocial.Services
{
    public class ServicioHistorias
    {
        private List<Historia> _historias = new List<Historia>();
        private int _nextId = 1;
        public List<Cuenta> Cuentas { get; }

        public ServicioHistorias()
        {
            // Inicializar la lista de cuentas predefinidas
            Cuentas = new List<Cuenta>
            {
                new Cuenta("Juan1", "Hombre", new DateTime(2000, 1, 1)),
                new Cuenta("Pedro", "Hombre", new DateTime(2002, 2, 2)),
                new Cuenta("María", "Mujer", new DateTime(1990, 3, 3)),
                new Cuenta("Carmen", "Mujer", new DateTime(1980, 4, 4)),
                new Cuenta("Valentina", "Mujer", new DateTime(2005, 5, 5))
            };

            // Agregar algunas historias de ejemplo
            AgregarHistoria(new Historia
            {
                NombreTitular = "Juan1",
                Titulo = "Mi primer día en la playa",
                TipoPublicacion = TipoPublicacion.Publico,
                TipoDocumento = TipoDocumento.Imagen
            });

            AgregarHistoria(new Historia
            {
                NombreTitular = "María",
                Titulo = "Receta de cocina familiar",
                TipoPublicacion = TipoPublicacion.Amigos,
                TipoDocumento = TipoDocumento.Video
            });

            AgregarHistoria(new Historia
            {
                NombreTitular = "Pedro",
                Titulo = "Mis pensamientos del día",
                TipoPublicacion = TipoPublicacion.SoloYo,
                TipoDocumento = TipoDocumento.Ninguno
            });
        }

        public List<Historia> ObtenerTodasLasHistorias()
        {
            return _historias;
        }

        public List<Historia> ObtenerHistoriasPublicas()
        {
            return _historias.Where(h => h.TipoPublicacion == TipoPublicacion.Publico).ToList();
        }

        public List<Historia> ObtenerHistoriasNoPublicas()
        {
            return _historias.Where(h => h.TipoPublicacion != TipoPublicacion.Publico).ToList();
        }

        public void AgregarHistoria(Historia historia)
        {
            historia.Id = _nextId++;
            _historias.Add(historia);
        }

        public Cuenta ObtenerCuentaPorNombre(string nombre)
        {
            return Cuentas.FirstOrDefault(c => c.Nombre == nombre);
        }
    }
}
