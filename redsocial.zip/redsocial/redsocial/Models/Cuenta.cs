﻿namespace RedSocial.Models
{
   
    
        public class Cuenta
        {
            public string Nombre { get; set; }
            public string Genero { get; set; }
            public DateTime FechaNacimiento { get; set; }

            public Cuenta(string nombre, string genero, DateTime fechaNacimiento)
            {
                Nombre = nombre;
                Genero = genero;
                FechaNacimiento = fechaNacimiento;
            }
        }
    }


