﻿
        namespace RedSocial.Models
    {
        public enum TipoPublicacion
        {
            Publico,
            Amigos,
            SoloYo,
            Otro
        }
    }


