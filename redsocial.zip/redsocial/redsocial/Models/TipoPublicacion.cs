﻿namespace RedSocial.Models
{
    public enum TipoDocumento
    {
        Imagen,
        Video,
        Audio,
        Ninguno
    }
}
