﻿using RedSocial.Models;
using System;
using System.ComponentModel.DataAnnotations;

namespace RedSocial.Models
{
    public class Historia
    {
        public int Id { get; set; }
        public DateTime FechaPublicacion { get; set; }
        public TimeSpan HoraPublicacion { get; set; }
        public string NombreTitular { get; set; }
        public string Titulo { get; set; }
        public TipoPublicacion TipoPublicacion { get; set; }
        public TipoDocumento TipoDocumento { get; set; }

        public Historia()
        {
            FechaPublicacion = DateTime.Today;
            HoraPublicacion = DateTime.Now.TimeOfDay;
        }
    }
}
